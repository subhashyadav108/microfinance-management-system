import sqlite3

# -----------------------------
# CONNECT DATABASE
# -----------------------------
conn = sqlite3.connect("microfinance.db")
cursor = conn.cursor()

# -----------------------------
# CREATE TABLES
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS customers (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS loans (
    loan_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    loan_amount REAL,
    status TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS repayments (
    repayment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    loan_id INTEGER,
    amount_paid REAL,
    date TEXT
)
""")

conn.commit()


# -----------------------------
# FUNCTIONS
# -----------------------------

def add_customer():
    name = input("Enter name: ")
    phone = input("Enter phone: ")

    cursor.execute(
        "INSERT INTO customers (name, phone) VALUES (?, ?)",
        (name, phone)
    )
    conn.commit()
    print("Customer added successfully!")


def view_customers():
    cursor.execute("SELECT * FROM customers")
    rows = cursor.fetchall()

    print("\n--- CUSTOMERS ---")
    for row in rows:
        print(row)


def search_customer():
    name = input("Enter name to search: ")

    cursor.execute(
        "SELECT * FROM customers WHERE name LIKE ?",
        ('%' + name + '%',)
    )

    results = cursor.fetchall()

    print("\n--- SEARCH RESULT ---")
    if results:
        for r in results:
            print(r)
    else:
        print("No customer found")


def customer_report():
    print("\n--- CUSTOMER LOAN REPORT ---")

    cursor.execute("""
    SELECT customers.name, loans.loan_amount, repayments.amount_paid
    FROM customers
    JOIN loans ON customers.customer_id = loans.customer_id
    JOIN repayments ON loans.loan_id = repayments.loan_id
    """)

    rows = cursor.fetchall()

    if rows:
        for row in rows:
            print(f"Name: {row[0]} | Loan: {row[1]} | Repaid: {row[2]}")
    else:
        print("No data available")


# -----------------------------
# MENU SYSTEM
# -----------------------------
while True:
    print("\n==============================")
    print(" MICROFINANCE MANAGEMENT SYSTEM")
    print("==============================")
    print("1. Add Customer")
    print("2. View Customers")
    print("3. Search Customer")
    print("4. Customer Loan Report")
    print("5. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        add_customer()
    elif choice == "2":
        view_customers()
    elif choice == "3":
        search_customer()
    elif choice == "4":
        customer_report()
    elif choice == "5":
        print("Exiting system...")
        break
    else:
        print("Invalid choice. Try again!")

# -----------------------------
# CLOSE CONNECTION
# -----------------------------
conn.close()