import sqlite3
import matplotlib.pyplot as plt

conn = sqlite3.connect("microfinance.db")
cursor = conn.cursor()

cursor.execute("SELECT loan_amount FROM loans")
loans = [x[0] for x in cursor.fetchall()]

plt.hist(loans, bins=10)
plt.title("Loan Distribution")
plt.xlabel("Loan Amount")
plt.ylabel("Number of Customers")
plt.show()