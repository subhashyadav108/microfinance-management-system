import sqlite3
import tkinter as tk
from tkinter import messagebox

conn = sqlite3.connect("microfinance.db")
cursor = conn.cursor()


def add_customer():
    name = entry_name.get()
    phone = entry_phone.get()

    cursor.execute("INSERT INTO customers (name, phone) VALUES (?, ?)", (name, phone))
    conn.commit()

    messagebox.showinfo("Success", "Customer Added!")


def show_customers():
    cursor.execute("SELECT * FROM customers")
    rows = cursor.fetchall()

    result = "\n".join([str(r) for r in rows])
    messagebox.showinfo("Customers", result)


# ---------------- GUI WINDOW ----------------
root = tk.Tk()
root.title("Microfinance System")
root.geometry("400x300")

tk.Label(root, text="Name").pack()
entry_name = tk.Entry(root)
entry_name.pack()

tk.Label(root, text="Phone").pack()
entry_phone = tk.Entry(root)
entry_phone.pack()

tk.Button(root, text="Add Customer", command=add_customer).pack(pady=5)
tk.Button(root, text="View Customers", command=show_customers).pack(pady=5)

root.mainloop()